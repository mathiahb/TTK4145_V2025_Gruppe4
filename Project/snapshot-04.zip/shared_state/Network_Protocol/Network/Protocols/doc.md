Protocols
---
Defines the Protocols for Synchronization and Update.

Synchronization
---
Everyone says hello, followed by their name and state.
Use worst-case logic to handle discrepancies in state. (And elevators have authority of their own state, using a consensus algorithm if they're not connected.)

Update
---
Uses 3PC to agree on updating a field to a new value.