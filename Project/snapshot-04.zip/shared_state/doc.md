Shared State
---
Not implemented yet.

Provides the shared state, a state that is shared between all nodes on the network provided by the Network-Protocol.
Accepts updates from the network, and defers updates from the elevator to the network.