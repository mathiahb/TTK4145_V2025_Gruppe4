How to start an elevator
---------------------------

program --id PORT


(Foreløpig instruksjon:
go run main.go --test --id PORT
)