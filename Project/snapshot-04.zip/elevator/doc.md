Elevator
---
Not fully implemented yet.

Implements the elevator functionality. Receiving information from the Hall Request Assigner and the shared state.